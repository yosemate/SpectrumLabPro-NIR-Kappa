import json,hashlib,sys
from pathlib import Path
import numpy as np
from sklearn.cross_decomposition import PLSRegression
ns={};exec(Path('work/sinteticos_cv/components.py').read_text().split('started=time.monotonic()')[0],ns)
e=ns['e'];rows=ns['rows'];r=json.loads(Path('work/sinteticos_cv/components_results.json').read_text())
selected=next(v for v in r['confirmed'] if v['config']==dict(scenario='broad',method='reflectance',components=1,autoscale=True))
x,y,parents=ns['gen'](rows,16,'broad',0);mean=x.mean(axis=0);sd=x.std(axis=0,ddof=1);z=(x-mean)/sd
model=PLSRegression(n_components=1,scale=False,max_iter=1000,tol=1e-10).fit(z,y)
coef=np.asarray(model.coef_).ravel()/sd
offset=float(model.predict(np.zeros((1,6))).ravel()[0])-float(mean@coef)
folds=[]
for index,f in enumerate(selected['runs'][0]['folds']):
 predictions=[run['folds'][index]['prediction'] for run in selected['runs']]
 folds.append(dict(test_sample=f['test_sample'],train_samples=f['parent_training_samples'],actual=f['reference'],predicted=float(np.mean(predictions))))
metrics=e.metrics([f['actual'] for f in folds],[f['predicted'] for f in folds])
recipe=dict(scenario='broad',n_per_parent=65536,seed=0,envelope=ns['ns']['ENVELOPES']['broad'] if 'ns' in ns else None)
# generator namespace contains the Sobol script definitions under ns, while this
# script keeps a separate outer dictionary; obtain the envelope deterministically.
recipe['envelope']={'scale':.20,'offset':.01,'tilt':.05,'noise':.01,'white':10}
cal=ns['ns']['cal']
export=dict(schema=1,method='raw',components=1,channels=e.CHANNELS,units='relative_fraction',mode='seco',reference=None,
 coef=coef.tolist(),offset=offset,sample_ids=parents,kappa_range=[4.27,19.95],
 limitation='EXPERIMENTAL SINTÉTICO — alvos herdados das quatro referências; seleção exploratória; sem validação industrial. Autoescalonamento incorporado aos coeficientes.',
 display_name='PLS sintético autoescalado experimental',
 training_preprocessing=dict(name='channel autoscaling folded into raw coefficients',mean=mean.tolist(),sample_std=sd.tolist()),
 synthetic_training=dict(generated_rows=len(x),original_measured_rows_in_estimator=0,real_parent_sample_count=4,recipe=recipe,
  calibration_id=cal['calibration_id'],global_cv_percent=cal['white_stats']['global_cv_mean']),
 validation=dict(validation='leave-one-physical-sample-out; generator never sees heldout sample; same four references used to explore scenarios; not independent confirmation',methods={'raw':{'metrics':metrics,'folds':folds}}))
export['source_sha256']=hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest()
# Verify equivalent inference in the existing supervisor, which accepts raw linear coefficients.
real=np.array([row['x'] for row in rows]);expected=model.predict((real-mean)/sd).ravel();actual=e.predict(export,real,'seco')
np.testing.assert_allclose(actual,expected,atol=1e-10)
full=[]
for sid in sorted({row['sample_id'] for row in rows}):
 rs=[row for row in rows if row['sample_id']==sid]
 full.append(dict(sample=sid,reference=rs[0]['kappa'],training_related_real_prediction=float(e.predict(export,[row['x'] for row in rs],'seco').mean())))
Path('outputs/PLS_Sintetico_Autoescalado_Experimental.json').write_text(json.dumps(export,indent=2,ensure_ascii=False))
summary={'selected':selected,'model_metrics':metrics,'full_fit_diagnostic_not_validation':full,'base_rows':len(x),'prediction_equivalence_test_passed':True}
Path('work/sinteticos_cv/final_summary.json').write_text(json.dumps(summary,indent=2))
print('FROZEN-SUPERVISOR INFERENCE COMPATIBLE',metrics,'FIT',full)
