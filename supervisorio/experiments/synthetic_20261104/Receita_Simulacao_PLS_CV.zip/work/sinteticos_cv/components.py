"""Exploratory latent-component screening with training-only synthetic points."""
import json,sys,time,warnings
from pathlib import Path
import numpy as np
from scipy.stats import qmc,norm
from sklearn.cross_decomposition import PLSRegression
ns={};exec(Path('work/sinteticos_cv/sobol.py').read_text().split('start=time.monotonic()')[0],ns)
rows=ns['rows'];generate=ns['generate'];e=ns['e'];global_cv=ns['cal']['white_stats']['global_cv_mean']/100
METHODS=['reflectance','sum','snv','log10','log10_snv']
SCENARIOS=['mild','moderate','broad','globalCV_1x','globalCV_3x','globalCV_10x']
processed=0

def trans(x,m):
 if m.startswith('log10'):x=-np.log10(x)
 if m=='sum':return x/x.sum(axis=1,keepdims=True)
 if m in ('snv','log10_snv'):return e.snv(x)
 return x

def gen(data,power,scenario,seed):
 if scenario in ['mild','moderate','broad']:
  x,y,ids,_=generate(data,power,scenario,seed)
  return x,y,ids
 ids=sorted({r['sample_id'] for r in data});xx=[];yy=[]
 multiplier=int(scenario.split('_')[1][:-1]);n=2**power
 for index,sid in enumerate(ids):
  rs=[r for r in data if r['sample_id']==sid];base=np.array([r['x'] for r in rs])
  u=qmc.Sobol(d=1,scramble=True,seed=seed*100+index).random_base2(power)
  factor=1+norm.ppf(np.clip(u,1e-9,1-1e-9))*global_cv*multiplier
  xx.append(base[np.arange(n)%len(base)]/factor);yy.extend([rs[0]['kappa']]*n)
 return np.vstack(xx),np.array(yy),ids

def score(config,power,seed):
 global processed
 truth=[];pred=[];folds=[]
 for sid in sorted({r['sample_id'] for r in rows}):
  train=[r for r in rows if r['sample_id']!=sid];test=[r for r in rows if r['sample_id']==sid]
  x,y,ids=gen(train,power,config['scenario'],seed);assert sid not in ids
  processed+=len(x);x=trans(x,config['method']);tx=trans(np.array([r['x'] for r in test]),config['method'])
  mean=x.mean(axis=0);sd=x.std(axis=0,ddof=1);sd[sd<1e-12]=1
  if config['autoscale']:x=(x-mean)/sd;tx=(tx-mean)/sd
  rank=np.linalg.matrix_rank(x-x.mean(axis=0),tol=max(np.linalg.norm(x-x.mean(axis=0),2)*1e-8,1e-12))
  if config['components']>rank:raise ValueError('Synthetic centered rank insufficient')
  with warnings.catch_warnings():
   warnings.simplefilter('error',RuntimeWarning)
   model=PLSRegression(n_components=config['components'],scale=False,max_iter=1000,tol=1e-10).fit(x,y)
  p=float(model.predict(tx).mean())
  if not np.isfinite(p):raise ValueError('Nonfinite prediction')
  truth.append(test[0]['kappa']);pred.append(p)
  folds.append(dict(test_sample=sid,parent_training_samples=ids,reference=truth[-1],prediction=p,synthetic_rows=len(x),original_real_rows_in_estimator=0))
 return dict(seed=seed,points_per_parent=2**power,metrics=e.metrics(truth,pred),folds=folds)

started=time.monotonic();screen=[]
for scenario in SCENARIOS:
 for method in METHODS:
  for components in range(1,7):
   for scale in [False,True]:
    config=dict(scenario=scenario,method=method,components=components,autoscale=scale)
    try:screen.append(dict(config=config,run=score(config,12,0)))
    except (ValueError,RuntimeWarning) as err:screen.append(dict(config=config,unavailable=str(err)))
  print('screen',scenario,method,flush=True)
ranked=sorted([v for v in screen if 'run' in v],key=lambda v:v['run']['metrics']['rmse'])
# Confirm top ten across larger low-discrepancy sets and 3 fixed scrambles; do not pick the best seed.
confirmed=[]
for candidate in ranked[:10]:
 runs=[score(candidate['config'],16,seed) for seed in [0,1,2]]
 errors=[v['metrics']['rmse'] for v in runs]
 confirmed.append(dict(config=candidate['config'],rmse_mean=float(np.mean(errors)),rmse_min=float(min(errors)),rmse_max=float(max(errors)),runs=runs))
 print('confirm',candidate['config'],np.mean(errors),flush=True)
report=dict(protocol='Exploratory screening, then fixed-seed confirmation. Real heldout physical sample excluded from generator parents and labels. Only synthetic points in estimator. Selection uses the same four reference outcomes and is not independent validation.',global_calibration_cv_percent=global_cv*100,screen=screen,confirmed=confirmed,processed_training_spectra=processed,elapsed_seconds=time.monotonic()-started)
Path('work/sinteticos_cv/components_results.json').write_text(json.dumps(report,indent=2))
print('TOTAL',processed,'TIME',report['elapsed_seconds'],flush=True)
