"""Training-only synthetic calibration-noise experiment; real held-out groups never used to generate training points."""
import json,sys,time
from pathlib import Path
import numpy as np
from sklearn.cross_decomposition import PLSRegression
sys.path.insert(0,'work/fw');import experimental_chemometrics as e
rows=json.loads(Path('work/reavaliacao/current_rows.json').read_text())
cal=json.loads(Path('calibration_source.json').read_text())['calibration']
white=np.array(cal['white_scans']);white_mean=white.mean(axis=0);dark=np.array(cal['vetor_escuro']);white_n=len(white)
# Mean-reference uncertainty with observed cross-channel covariance. Assumes stable,
# exchangeable scans; possible drift is separately documented, not declared corrected.
cov=np.cov(white,rowvar=False,ddof=1)/white_n
vals,vecs=np.linalg.eigh(cov);root=vecs@np.diag(np.sqrt(np.maximum(vals,0)))
NS=[200,2000,20000];SEEDS=list(range(5));METHODS=['reflectance','sum','snv','log10'];SCENARIOS=['white_1x','white_3x','white_10x','white_sample_scatter','white_mixup']
processed=0

def transform(x,method):
 if method=='sum':return x/x.sum(axis=1,keepdims=True)
 if method=='snv':return e.snv(x)
 if method=='log10':return -np.log10(x)
 return x

def generate(training,n,scenario,seed,keep_lineage=False):
 rng=np.random.default_rng(seed);ids=sorted({r['sample_id'] for r in training});x=[];y=[];origin=[];kind=[]
 raw=[];targets=[]
 multiplier={'white_1x':1,'white_3x':3,'white_10x':10,'white_sample_scatter':3,'white_mixup':3}[scenario]
 for sid in ids:
  group=[r for r in training if r['sample_id']==sid]
  base=np.array([r['x'] for r in group]);base=base[np.arange(n)%len(base)].copy();raw.append(np.mean([r['x'] for r in group],axis=0));targets.append(group[0]['kappa'])
  perturbed_white=white_mean+multiplier*(rng.normal(size=(n,6))@root.T)
  if np.any(perturbed_white-dark<=0):raise ValueError('Nonpositive virtual reference')
  sample=base*(white_mean-dark)+dark
  if scenario in ['white_sample_scatter','white_mixup']:
   sample=sample*(1+rng.normal(0,.0025,(n,6)))
   sample=(sample-dark)*rng.uniform(.95,1.05,(n,1))+dark
   sample+=(white_mean-dark)*rng.uniform(-.002,.002,(n,1))
  point=(sample-dark)/(perturbed_white-dark)
  if np.any(point<=0):raise ValueError('Nonpositive generated reflectance')
  x.append(point);y.extend([group[0]['kappa']]*n)
  if keep_lineage:origin.extend([sid]*n);kind.extend(['synthetic_perturbation']*n)
 if scenario=='white_mixup':
  for i in range(len(ids)):
   for j in range(i+1,len(ids)):
    a=((np.arange(n)+.5)/n)[:,None]
    base=a*raw[i]+(1-a)*raw[j]
    perturbed_white=white_mean+multiplier*(rng.normal(size=(n,6))@root.T)
    point=base*(white_mean-dark)/(perturbed_white-dark)
    point*=1+rng.normal(0,.0025,(n,6))
    x.append(point);y.extend((a[:,0]*targets[i]+(1-a[:,0])*targets[j]).tolist())
    if keep_lineage:origin.extend([ids[i]+'+'+ids[j]]*n);kind.extend(['synthetic_mixup_hypothesis']*n)
 return np.vstack(x),np.array(y),origin,kind,ids

start=time.monotonic();results=[]
for scenario in SCENARIOS:
 for n in NS:
  for method in METHODS:
   runs=[]
   for seed in SEEDS:
    truth=[];pred=[];folds=[]
    for sid in sorted({r['sample_id'] for r in rows}):
     train=[r for r in rows if r['sample_id']!=sid];test=[r for r in rows if r['sample_id']==sid]
     aug,y,_,_,parents=generate(train,n,scenario,seed)
     assert sid not in parents
     processed+=len(aug)
     # Only generated points are supplied to fit. No original measured row is appended.
     model=PLSRegression(n_components=1,scale=False,max_iter=1000,tol=1e-10).fit(transform(aug,method),y)
     value=float(model.predict(transform(np.array([r['x'] for r in test]),method)).mean())
     truth.append(test[0]['kappa']);pred.append(value)
     folds.append(dict(test_sample=sid,parent_training_samples=parents,reference=truth[-1],prediction=value,synthetic_rows=len(aug),original_measured_rows_in_estimator=0))
    runs.append(dict(seed=seed,metrics=e.metrics(truth,pred),folds=folds))
   scores=[r['metrics']['rmse'] for r in runs]
   result=dict(scenario=scenario,synthetic_per_parent_or_pair=n,method=method,rmse_mean=float(np.mean(scores)),rmse_min=float(min(scores)),rmse_max=float(max(scores)),runs=runs)
   results.append(result);print(scenario,n,method,round(result['rmse_mean'],6),flush=True)
report=dict(protocol='Only synthetic rows in estimator; outer real physical sample excluded from generation (spectra and Kappa). All repeated readings grouped. Four real laboratory references scored; Eldorado assumed excluded.',
 calibration_id=cal['calibration_id'],white_n=white_n,white_cv_percent=cal['white_stats']['cv_percent'],mean_reference_covariance=cov.tolist(),
 assumption='Observed white-scan covariance divided by 10 models uncertainty of mean reference, assuming exchangeable scans. Stress multipliers 3 and 10 are scenarios, not measured guarantees. Sample scatter/noise/offset and mixup relation are hypotheses. Calibration characterization is shared; individual heldout sample spectra and labels are not used in synthetic generation.',
 processed_training_spectra=processed,elapsed_seconds=time.monotonic()-start,results=results)
Path('work/sinteticos_cv/results.json').write_text(json.dumps(report,indent=2))
print('TOTAL',processed,'SECONDS',report['elapsed_seconds'],flush=True)
