"""Low-discrepancy coverage of declared nuisance envelopes, not all physical spectra."""
import json,sys,time
from pathlib import Path
import numpy as np
from scipy.stats import qmc, norm
from sklearn.cross_decomposition import PLSRegression
sys.path.insert(0,'work/fw');import experimental_chemometrics as e
rows=json.loads(Path('work/reavaliacao/current_rows.json').read_text())
cal=json.loads(Path('calibration_source.json').read_text())['calibration']
w=np.array(cal['white_scans']);wm=w.mean(axis=0);cov=np.cov(w,rowvar=False,ddof=1)/len(w);ev,vec=np.linalg.eigh(cov);root=vec@np.diag(np.sqrt(np.maximum(ev,0)))
CHANNEL_AXIS=(np.array(e.CHANNELS)-np.mean(e.CHANNELS))/np.ptp(e.CHANNELS)*2
ENVELOPES={'mild':dict(scale=.05,offset=.002,tilt=.01,noise=.0025,white=1),
 'moderate':dict(scale=.10,offset=.005,tilt=.02,noise=.005,white=3),
 'broad':dict(scale=.20,offset=.01,tilt=.05,noise=.01,white=10)}
METHODS=['reflectance','sum','snv','log10'];SEEDS=[0,1,2];POWERS=[12,14,16]
processed=0

def transform(x,method):
 if method=='sum':return x/x.sum(axis=1,keepdims=True)
 if method=='snv':return e.snv(x)
 if method=='log10':return -np.log10(x)
 return x

def generate(training,power,envelope,seed,lineage=False):
 ids=sorted({r['sample_id'] for r in training});xs=[];ys=[];parents=[];raw_ranges=[];cfg=ENVELOPES[envelope]
 for index,sid in enumerate(ids):
  group=[r for r in training if r['sample_id']==sid];base=np.array([r['x'] for r in group]);n=2**power
  u=qmc.Sobol(d=15,scramble=True,seed=seed*100+index).random_base2(power)
  centered=2*u-1
  noise=norm.ppf(np.clip(u[:,3:9],1e-9,1-1e-9))*cfg['noise']
  drift=norm.ppf(np.clip(u[:,9:15],1e-9,1-1e-9))@root.T*cfg['white']
  sample=base[np.arange(n)%len(base)].copy()
  sample*=1+cfg['scale']*centered[:,0:1]
  sample*=1+cfg['tilt']*centered[:,2:3]*CHANNEL_AXIS[None,:]
  sample*=1+noise
  sample+=cfg['offset']*centered[:,1:2]
  sample*=wm/(wm+drift)
  if np.any(sample<=0):raise ValueError('Generated nonpositive spectral fraction')
  xs.append(sample);ys.extend([group[0]['kappa']]*n)
  if lineage:parents.extend([sid]*n)
 return np.vstack(xs),np.array(ys),ids,parents

start=time.monotonic();results=[]
for envelope in ENVELOPES:
 for power in POWERS:
  for method in METHODS:
   runs=[]
   for seed in SEEDS:
    true=[];pred=[];folds=[]
    for sid in sorted({r['sample_id'] for r in rows}):
     training=[r for r in rows if r['sample_id']!=sid];test=[r for r in rows if r['sample_id']==sid]
     x,y,ids,_=generate(training,power,envelope,seed)
     assert sid not in ids
     processed+=len(x)
     model=PLSRegression(n_components=1,scale=False,max_iter=1000,tol=1e-10).fit(transform(x,method),y)
     value=float(model.predict(transform(np.array([r['x'] for r in test]),method)).mean())
     true.append(test[0]['kappa']);pred.append(value)
     folds.append(dict(test_sample=sid,parent_training_samples=ids,reference=true[-1],prediction=value,synthetic_rows=len(x),original_measured_rows_in_estimator=0))
    runs.append(dict(seed=seed,metrics=e.metrics(true,pred),folds=folds))
   scores=[run['metrics']['rmse'] for run in runs]
   result=dict(envelope=envelope,points_per_parent=2**power,method=method,rmse_mean=float(np.mean(scores)),rmse_min=float(min(scores)),rmse_max=float(max(scores)),runs=runs)
   results.append(result);print(envelope,2**power,method,round(result['rmse_mean'],6),flush=True)
report=dict(protocol='Only synthetic estimator inputs; heldout physical sample excluded from all generator parents and labels. Four real groups only. Sobol dimension 15 covers declared bounded/gaussian nuisance envelopes, not all possible spectra or new chemical reference information.',envelopes=ENVELOPES,processed_training_spectra=processed,elapsed_seconds=time.monotonic()-start,results=results)
Path('work/sinteticos_cv/sobol_results.json').write_text(json.dumps(report,indent=2))
print('TOTAL',processed,'TIME',report['elapsed_seconds'],flush=True)
