import json,gzip,csv,hashlib,zipfile
from pathlib import Path
ns={};exec(Path('work/sinteticos_cv/components.py').read_text().split('started=time.monotonic()')[0],ns)
rows=ns['rows'];gen=ns['gen'];root=Path('work/sinteticos_cv/bases');root.mkdir(exist_ok=True)
scenarios=ns['SCENARIOS'];manifest={'kind':'synthetic-only experimental bases for grouped holdout; not new laboratory references',
 'points_per_parent_per_scenario':16384,'scenarios':scenarios,'real_physical_reference_count':4,
 'global_calibration_cv_percent':ns['global_cv']*100,'seed':0,'files':[],
 'usage':'Use only the file whose excluded_sample matches the real test sample. Do not merge folds and then score the same four real samples; that would leak their source spectra and labels.'}
for excluded in sorted({r['sample_id'] for r in rows}):
 train=[r for r in rows if r['sample_id']!=excluded];path=root/('sem_'+excluded.replace('.','_')+'.csv.gz');count=0
 with gzip.open(path,'wt',encoding='utf-8',newline='',compresslevel=5) as f:
  writer=csv.writer(f);writer.writerow(['excluded_sample','parent_sample','is_synthetic','reference_status','kappa_assigned','scenario','r610','r680','r730','r760','r810','r860'])
  for scenario in scenarios:
   x,y,parents=gen(train,14,scenario,0)
   assert excluded not in parents
   n=16384
   for i,(spectrum,target) in enumerate(zip(x,y)):
    writer.writerow([excluded,parents[i//n],True,'synthetic_inherited',format(target,'.10g'),scenario,*[format(v,'.10g') for v in spectrum]])
   count+=len(x)
 manifest['files'].append({'file':path.name,'excluded_sample':excluded,'parent_samples':sorted({r['sample_id'] for r in train}),'synthetic_rows':count,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 print(path.name,count,flush=True)
(root/'manifest.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile('outputs/Bases_Sinteticas_PLS_CV_Experimental.zip','w',zipfile.ZIP_STORED) as archive:
 for p in root.iterdir():archive.write(p,p.name)
print('TOTAL_ROWS',sum(f['synthetic_rows'] for f in manifest['files']),flush=True)
