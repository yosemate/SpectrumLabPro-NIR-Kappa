Receita experimental: executar a partir desta pasta com Python, numpy, scipy e scikit-learn (versão usada: 1.9.1).
python work/sinteticos_cv/components.py
python work/sinteticos_cv/export_bases.py
python work/sinteticos_cv/finalize.py
Criar antes a pasta outputs. Não mesclar as quatro bases para avaliar as mesmas amostras: isso contamina o teste. Os alvos sintéticos são herdados; não são resultados de laboratório.
